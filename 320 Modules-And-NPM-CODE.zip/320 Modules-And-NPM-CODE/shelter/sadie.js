module.exports = {
    name: 'sadie',
    color: 'black'
}